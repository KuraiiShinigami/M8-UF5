/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco;
import java.util.ArrayList;



/**
 *
 * @author Daniel
 */

public class CuentasDadas {
  CPersona per;

    private int num;
     static CPersona[] person;
    static ArrayList<CCompteBancari> cuenta;
    private int numerodepersona;
    public double disponible;
    public int contador=0;
    
    
    public CuentasDadas() {        
        person = new CPersona[5];
        cuenta = new ArrayList<>();
        numerodepersona = 0;
        
        
    
    }

    public int getNumerodepersona() {
        return numerodepersona;
    }
    public boolean EstaCompleto(){
        return numerodepersona == person.length;
    }
    public int CreacioCuenta(CPersona perso){
        person[numerodepersona]= perso;
        cuenta.add(new CCompteBancari(person[numerodepersona]));
        numerodepersona++;
        contador++;
        return cuenta.get(cuenta.size() - 1).getNumero();
    }
    public CPersona buscarperson(int cuen, int contraseña){
        for(CCompteBancari cuentt : cuenta){
            if (cuentt.getNumero() == cuen) {
                if (cuentt.getPropietari().getNumero_secret() == contraseña) {
                    return cuentt.getPropietari();
                }
                return null;
            }
        }
        return null;
    }
    
    public  int ValidacionUsuari(int cuent, int contraseña){
        for (CCompteBancari cuents : cuenta) {
            if (cuents.getNumero() == cuent) {
                if (cuents.getPropietari().getNumero_secret() == contraseña) {
                    return cuenta.indexOf(cuents);
                }
                return -1;
            }
        }
        return -1;        
    }
    
    public CPersona buscadorPersona(int posicion) {
        return person[posicion];
    }
    //eliminamos la cuenta con el metodo de array list
    public void eliminarCuenta(int posicion) {
        cuenta.remove(posicion);

    }  
    //amb bucle busquem la persona
    public void modifyCompte(CPersona persona, String nombre) {
        for (int j = 0; j < numerodepersona; j++) {
            if (person[j].getNom().equalsIgnoreCase(nombre)) {
                person[j].setNom(persona.getNom());
                person[j].setPrimer_cognom(persona.getPrimer_cognom());
                person[j].setSegon_cognom(persona.getSegon_cognom());
            }
        }
    }
    //ingresar dinero
    public double ingresar(int cuent, int numeroSecreto, float dinero) {

        for (CCompteBancari cuentaS : cuenta) {
            if (cuentaS.getNumero() == cuent) {
                cuentaS.ingresar(dinero, numeroSecreto);
                return cuentaS.getSaldo();
            }
        }
        return 0;
    }
    
    public double Consultasaldo(int cuent, int secre) {
        for (CCompteBancari cuentas : cuenta) {
            if (cuentas.getNumero() == cuent) {                
                    return cuentas.getSaldo();                               
            }
            
        }
        return 0;
    }
    
     public double Retirardinero(int cuent, int numeroSecreto, float dinero) {

        for (CCompteBancari cuentA : cuenta) {
            if (cuentA.getNumero() == cuent && cuentA.getSaldo()>dinero) {
                
                cuentA.extraer(dinero, numeroSecreto);
                return cuentA.getSaldo();
            }
        }
        return 0;
    }
     
     public void cambSecre(int cuent, int numero) {
         
        for (CCompteBancari cuentA : cuenta){
            if (cuentA.getNumero() == cuent){
                cuentA.getPropietari().setNumero_secret(numero);               
            }                      
        }
        
    }
   
     
     
     
}
