/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco;

/**
 *
 * @author Daniel
 */
public class CCompteBancari{
    private int numero;
    private CPersona propietari;
    private double saldo;

    private static double saldo_inicial = 500;
    private static int seguent_compte = 1234;

    public CCompteBancari(CPersona propietari) {        
        
        this.propietari = propietari;
        this.saldo = saldo_inicial;                 
        this.numero= seguent_compte;
        seguent_compte++; 
    }
    public CCompteBancari(CCompteBancari objs){        
        this.numero = objs.numero;
        this.numero = objs.numero;
        this.propietari = objs.propietari;
        this.saldo = objs.saldo; 
    }
    //get y set propietari
    public CPersona getPropietari() {
        return propietari;
    }
    public void setPropietari(CPersona propietari) {
        this.propietari = propietari;
    }
    //get numero
    public int getNumero() {
        return numero;
    }
    //metode per modificar el saldo inicial
    public static void modifySaldo(int modificacion){
        saldo_inicial = modificacion;
    }
    //metodo get para el saldo
    public double getSaldo() {
        
        return saldo;
    }
    //metodo comprovar el numero secreto
    public boolean CompruebaNumeroSecreto(int a, int b){
        if(a==b){
            return true;
        }
        else{
            return false;
        }
    }    
    //metodo ingresar
    public boolean ingresar(float cantidad_ingresar, int num_secreto){
        if (num_secreto==propietari.getNumero_secret()) {
            this.saldo+=(cantidad_ingresar);
            return true;
        }
        else{
            return false;
        }
        
    }
    //metodo extraer dinero
    public boolean extraer(float cantidad_extraer, int num_secreto){
        if (num_secreto==propietari.getNumero_secret()) {
            this.saldo-=cantidad_extraer;
            return true;
        }
        else{
            return false;
        }
        
    }
    //metodo passar dinero

    @Override
    public String toString() {
        return "Numero compte=" + numero +  ", Saldo=" + saldo + "]";
    }
    
}
