/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco;

/**
 *
 * @author Daniel
 */
public class CPersona{

    private String nom;
    private String primer_cognom;
    private String segon_cognom;
    private int numero_secret;

    //constructor principal
    public CPersona(String nom, String primer_cognom, String segon_cognom, int numero_secret) {
        this.nom = nom;
        this.primer_cognom = primer_cognom;
        this.segon_cognom = segon_cognom;
        this.numero_secret = numero_secret;
    }
    public CPersona(String nom,String primer_cognom,String segon_cognom){
        this.nom=nom;
        this.primer_cognom=primer_cognom;
        this.segon_cognom=segon_cognom;
        

    }
    //constructor copia
    public CPersona(CPersona obj){
        this.nom = obj.nom;
        this.primer_cognom = obj.primer_cognom;
        this.numero_secret = 2;
        this.numero_secret = obj.numero_secret; //prova 
    }


    //Getters y Setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrimer_cognom() {
        return primer_cognom;
    }

    public void setPrimer_cognom(String primer_cognom) {
        this.primer_cognom = primer_cognom;
    }

    public String getSegon_cognom() {
        return segon_cognom;
    }

    public void setSegon_cognom(String segon_cognom) {
        this.segon_cognom = segon_cognom;
    }

    public int getNumero_secret() {
        return numero_secret;
    }

    public void setNumero_secret(int numero_secret) {
        this.numero_secret = numero_secret;
    }
    @Override
    public String toString() {
        return "Nom=" + nom + ", numero_secret=" + numero_secret + ", primer_cognom=" + primer_cognom
                + ", segon_cognom=" + segon_cognom ;
    }

    
    
}
